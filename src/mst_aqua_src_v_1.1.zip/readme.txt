-= MSX Sketch Tools - Aquarela =-

1- Running MSX Sketch Tools - Aquarela

This program runs under any Operational System that has a Java Virtual Machine installed.
The program "aqu2gif" converts an Aquarela file to GIF, while "gif2aqu" converts a GIF image to a specific Aquarela file.

At the command prompt, use:
java aqu2gif
or
java gif2aqu

Two parameters must be passed to both programs through command line: the option and the input file name. The output file name is created AUTOMATICALLY from the input file name.

Available options:
-fonte - indicates Aquarela's font ".fnt" file format for the input/output file.
-sprite - indicates Aquarela's sprite ".spr" file format for the input/output file.
-padrao - indicates Aquarela's pattern ".prd" file format for the input/output file.

For the "aqu2gif", the input file is an Aquarela format, while "gif2aqu" the input file is a GIF file.


1.1- Example on how to convert from Aquarela to GIF

java aqu2gif -sprite naves.spr

The file "naves.GIF" is created.


1.2- Example on how to convert from GIF to Aquarela

java gif2aqu -fonte courier.gif

The file "courier.FNT" is created.


1.3. Important notes

If you convert an Aquarela file to GIF in order to edit and modify it, please change the name of the modified GIF file. Otherwise, the original Aquarela file will be overwrited by the backwards convertion from GIF to Aquarela.
Also, verify if the automatic output file has a homonymous file. In that case, rename the input file in order to not overwrite the existing file.


2- The GIF models

This program include three GIF files used as models to edit each Aquarela format. They were designed to be edited in order to create the patterns to be converted to Aquarela's format. If you are converting from Aquarela to GIF, the program itself creates the GIF model file already filled with the patterns.
Attention: the gray lines are used to separate the patterns and it is never used.


3- Informations

Author: Marcelo Silveira
Homepage: http://marmsx.msxall.com
e-mail: flamar98@hotmail.com
