/***************************************************************************
 *   Class gif2aqu - converte GIF para aquarela                            *
 *                                                                         *
 *   Copyright (C) 2018 by Marcelo Silveira                                *
 *   MSX Sketch Tools: http://marmsx.msxall.com                            *
 *   Contact: flamar98@hotmail.com                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;


public class gif2aqu {

  static int tipo;


  //
  // Ajustes gerais
  //

  static void help() {
    System.out.println("-= MSX Sketch Tools - gif2aqu v1.1 =-");
    System.out.println("MarMSX 2018 - http://marmsx.msxall.com");
    System.out.println("Converte GIF para fonte, sprite ou padrão do Aquarela");
    System.out.println("Uso: java aqu2gif -opcao <arquivo>");
    System.out.println("Opções:");
    System.out.println("-fonte - converte para fonte (.fnt) do Aqurela"); 
    System.out.println("-sprite - converte para sprite (.spr) do Aqurela");
    System.out.println("-padrao - converte para padrao (.prd) do Aqurela");
    System.out.println("Exemplo:");
    System.out.println("java gif2aqu -fonte letras.gif");
    System.out.println("** Atenção: utilizar os arquivos GIF do gabarito **");
  }

  static boolean ajustaTipo(String opt) {
    String lista_tipos[] = {"-fonte", "-sprite", "-padrao" };

    tipo = 0;
    for (int i=0; i<3; i++) {
      if (opt.equals(lista_tipos[i])) {
        tipo = i+1;
        break;
      }
    }
    return (tipo>0);
  }


  //
  // Conversão para GIF
  //

  public static byte setBit(byte data, int b, boolean v) {
    int mask= 1 << b;

    if (v)
      return (byte) (data | mask);

    return (byte) (data & ~mask);
  }

  static void formataSprite(BufferedImage img, byte[] data, int file_size) {
    int p=7;

    for (int y=1; y<img.getHeight(); y+=17) {
      for (int x=1; x<img.getWidth(); x+=17) {
        for (int xx=0; xx<16; xx+=8) {
          for (int yy=0; yy<16; yy++) {
            if (p >= file_size)
              continue;
            for (int b=0; b<8; b++)
              data[p] = setBit(data[p], b, (img.getRGB(x+xx+(7-b), y+yy) & 0xFF) < 128);
            p++;
          }
        }
      }
    }
  }

  static void formataPadrao(BufferedImage img, byte[] data) {
    int p=0x67;

    for (int y=1; y<img.getHeight(); y+=9) {
      for (int x=1; x<img.getWidth(); x+=9) {
        for (int yy=0; yy<8; yy++) {
          for (int b=0; b<8; b++)
            data[p] = setBit(data[p], b, (img.getRGB(x+(7-b), y+yy) & 0xFF) < 128);
          p++;
        }
      }
    }
  }

  static void converte(String nomearq) {
    File arq = new File(nomearq);
    if (!arq.exists()) {
      System.out.println("Arquivo "+nomearq+" não existe.");
      return;
    }

    String ext[] = {".FNT", ".SPR", ".PRD"};
    String nomearq2 = nomearq.substring(0, nomearq.length()-4) + ext[tipo-1];
    int file_size=(tipo==1)?1479:2055;
    int width=137, height=(tipo==1)?103:137, step=17;

    // Se tipo for "padrões"
    if (tipo==3) {
      file_size = 256;
      width = 37;
      height = 37;
      step=9;
    }

    // Abre arquivo GIF
    BufferedImage img;
    try {
      img = ImageIO.read(new File(nomearq));
    }
    catch(Exception e) {
      System.out.println("Erro ao abrir o arquivo GIF.");
      return;
    }

    if (img==null) {
      System.out.println("Erro ao abrir o arquivo GIF.");
      return;
    }

    // Verifica se tamanho é compatível
    if (img.getWidth() != width || img.getHeight() != height) {
      System.out.println("Arquivo com tamanho diferente do gabarito.");
      return;
    }

    // Cria o arquivo de dados
    byte data[] = new byte[file_size];

    // Adiciona header
    int end_ini[] = {0xBFE0, 0x3800, 0x8408};
    data[0] = (byte) 0xFE;
    data[1] = (byte) (end_ini[tipo-1] & 0xFF);
    data[2] = (byte) ((end_ini[tipo-1] >> 8) & 0xFF);
    data[3] = (byte) ((end_ini[tipo-1]+file_size-8) & 0xFF);
    data[4] = (byte) (((end_ini[tipo-1]+file_size-8) >> 8) & 0xFF);
    data[5] = data[1];
    data[6] = data[2];

    // Formata
    if (tipo !=3 )
      formataSprite(img, data, file_size);
    else
      formataPadrao(img, data);

    // Salva arquivo
    try {
      OutputStream os = new FileOutputStream(nomearq2);
      os.write(data);
      os.close();
    }
    catch(Exception e) {
      System.out.println("Erro ao salvar o arquivo.");
      return;
    }
  }


  //
  // Método principal da classe
  //

  public static void main(String args[]) {

    if (args.length == 2) {
      if (ajustaTipo(args[0]))
        converte(args[1]);
      else
        help();
    }
    else
      help();
  }
}
