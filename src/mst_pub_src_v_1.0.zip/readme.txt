-= MSX Sketch Tools - Publisher =-

1- Running MSX Sketch Tools - Publisher

This program runs under any Operational System that has a Java Virtual Machine installed.

Included programs:
- pm2gif - Converts Page-Maker .PM? files to a single GIF image.
- gif2pm - Converts a single GIF image to four Page-Maker .PM? files.
- dp2gif - Converts Dynamic Publisher .PCT to GIF image.
- gif2dp - Converts  GIF image to Dynamic Publisher .PCT.
- fnt2gif - Converts Dynamic Publisher font .FNT to GIF image.

At the command prompt, use:
java <program>

Only one parameter must be passed to any program in this package through command line: the input file name. The output file name is created AUTOMATICALLY from the input file name.


1.1- Examples

java pm2gif pagina
The file "pagina.GIF" is created.

java gif2pm2 pagina.gif
The files "pagina.PM1", "pagina.PM2", "pagina.PM3" and "pagina.PM4" are created.


1.2. Important notes

If you convert an Aquarela file to GIF in order to edit and modify it, please change the name of the modified GIF file. Otherwise, the original Aquarela file will be overwrited by the backwards convertion from GIF to Aquarela.
Also, verify if the automatic output file has a homonymous file. In that case, rename the input file in order to not overwrite the existing file.


2- Informations

Author: Marcelo Silveira
Homepage: http://marmsx.msxall.com
e-mail: flamar98@hotmail.com
