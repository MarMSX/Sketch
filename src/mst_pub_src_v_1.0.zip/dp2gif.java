/***************************************************************************
 *   Class dp2gif - converte Dynamic Publisher para GIF                    *
 *                                                                         *
 *   Copyright (C) 2018 by Marcelo Silveira                                *
 *   MSX Sketch Tools: http://marmsx.msxall.com                            *
 *   Contact: flamar98@hotmail.com                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

import java.io.*;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Color;
import javax.imageio.ImageIO;


public class dp2gif {

  //
  // Ajuda
  //

  static void help() {
    System.out.println("-= MSX Sketch Tools - dp2gif =-");
    System.out.println("MarMSX 2018 - http://marmsx.msxall.com");
    System.out.println("Converte arquivo do Dynamic Publisher para imagem GIF");
    System.out.println("Uso: java dp2gif <arquivo>");
    System.out.println("Exemplo:");
    System.out.println("java dp2gif pagina.pct");
  }


  //
  // Conversão para GIF
  //

  static boolean getPixelBit(byte pixel, int b) {
    return (boolean) (((pixel & (1 << b)) >> b) == 1);
  }

  static byte switchNibbles(byte val) {
    int N1 = (val >> 4) & 0xF, N2 = val & 0xF;

    return (byte) ((N2 << 4) + N1);
  }

  static void renderiza(BufferedImage img, byte[] data) {
    byte dado;
    int p=0;

    for (int y=0; y<img.getHeight(); y++) {
      for (int x=0; x<img.getWidth(); x+=8) {
        dado = switchNibbles(data[p]);
        for (int b=0; b<8; b++)
          img.setRGB(x+(7-b), y, (getPixelBit(dado,b))?0:0xFFFFFF);
        p++;
      }
    }
  }

  static void descompacta(byte [] data, byte [] desc_data) {
    int R, D;
    int p=0, p_data=0x180;

    while (p_data < data.length && p < desc_data.length) {
      R = data[p_data++];

      // Testa bit 7
      if (getPixelBit((byte) R,7)) {
        R = R & 0x7F;
        D = data[p_data++];
        for (int i=0; i<=R; i++)
          desc_data[p++] = (byte) D;
      } 
      else {
        for (int i=0; i<=R; i++) {
          D = data[p_data++];
          desc_data[p++] = (byte) D;
        }
      }
    }
  }

  static void converte(String nomearq) {
    // Testes no arquivo
    File arq = new File(nomearq);
    if (!arq.exists()) {
      System.out.println("Arquivo "+nomearq+" não existe.");
      return;
    }
    if (nomearq.length() < 5) {
      System.out.println("Nome de arquivo curto.");
      return;
    }

    // Abre arquivo e o coloca em um vetor
    byte[] data = new byte[(int) arq.length()];
    try {
      InputStream is = new FileInputStream(arq);
      is.read(data);
      is.close();
    }
    catch(Exception e) {
      System.out.println("Erro ao abrir o arquivo.");
      return;
    }

    // Cria a imagem vazia
    BufferedImage img;
    int width=512, height=704;
    int bg_color = 0xFFFFFF;
    img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    Graphics2D g2d = img.createGraphics();
    g2d.setColor(new Color(bg_color));
    g2d.fillRect(0, 0, width, height);

    // Descompacta e renderiza imagem
    byte desc_data[] = new byte[64*704];
    descompacta(data, desc_data);
    renderiza(img, desc_data);

    // Salva arquivo GIF
    String nomearq2 = nomearq.substring(0, nomearq.length()-4) + ".GIF";
    try {
      File arq_gif = new File(nomearq2);
      ImageIO.write(img, "gif", arq_gif);
    }
    catch(Exception e) {
      System.out.println("Erro ao salvar o arquivo GIF.");
    }
  }


  //
  // Método principal da classe
  //

  public static void main(String args[]) {

    if (args.length == 1)
      converte(args[0]);
    else
      help();
  }
}
