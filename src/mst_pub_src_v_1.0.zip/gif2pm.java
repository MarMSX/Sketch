/***************************************************************************
 *   Class gif2pm - converte GIF para Page-Maker                           *
 *                                                                         *
 *   Copyright (C) 2018 by Marcelo Silveira                                *
 *   MSX Sketch Tools: http://marmsx.msxall.com                            *
 *   Contact: flamar98@hotmail.com                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.Arrays;


public class gif2pm {

  //
  // Ajuda
  //

  static void help() {
    System.out.println("-= MSX Sketch Tools - gif2pm =-");
    System.out.println("MarMSX 2018 - http://marmsx.msxall.com");
    System.out.println("Converte imagem GIF para arquivo do Page-Maker");
    System.out.println("Uso: java gif2pm <imagem>");
    System.out.println("Exemplo:");
    System.out.println("java gif2pm pagina.gif");
  }


  //
  // Conversão para GIF
  //

  public static byte setBit(byte data, int b, boolean v) {
    int mask= 1 << b;

    if (v)
      return (byte) (data | mask);

    return (byte) (data & ~mask);
  }

  static void formataSC2(BufferedImage img, byte[] data) {
    byte dado;
    int p=0;

    for (int y=0; y<img.getHeight(); y+=8) {
      for (int x=0; x<img.getWidth(); x+=8) {
        for (int yy=0; yy<8; yy++) {
          dado = data[p];
          for (int b=0; b<8; b++)
            data[p] = setBit(data[p], b, (img.getRGB(x+(7-b), y+yy) & 0xFF) < 128);
          p++;
        }
      }
    }
  }

  static void converte(String nomearq) {
    File arq = new File(nomearq);
    if (!arq.exists()) {
      System.out.println("Arquivo "+nomearq+" não existe.");
      return;
    }

    // Abre arquivo GIF
    BufferedImage img;
    try {
      img = ImageIO.read(new File(nomearq));
    }
    catch(Exception e) {
      System.out.println("Erro ao abrir o arquivo GIF.");
      return;
    }

    if (img==null) {
      System.out.println("Erro ao abrir o arquivo GIF.");
      return;
    }

    // Verifica se tamanho é compatível
    if (img.getWidth() != 512 || img.getHeight() != 768) {
      System.out.println("Arquivo com tamanho diferente.");
      return;
    }

    // Cria dados vazios
    byte[] data = new byte[49152];

    // Formata para screen 2
    formataSC2(img, data);

    // Nomes dos arquivos de saída
    String pm_file[] = new String[4];
    for (int i=0; i<4; i++)
      pm_file[i] = nomearq.substring(0,nomearq.length()-4)+".PM"+Integer.toString(i+1);

    // Cria arquivos
    byte[] file_data;
    int p;

    for (int i=0; i<4; i++) {
      arq = new File(pm_file[i]);

      try {
        OutputStream os = new FileOutputStream(arq);
        p=12288*i;
        file_data = Arrays.copyOfRange(data, p, p+12287);
        os.write(file_data);
        os.close();
      }
      catch(Exception e) {
        System.out.println("Erro ao salvar arquivos.");
        return;
      }
    }
  }


  //
  // Método principal da classe
  //

  public static void main(String args[]) {

    if (args.length == 1)
      converte(args[0]);
    else
      help();
  }
}
