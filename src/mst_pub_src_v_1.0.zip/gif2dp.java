/***************************************************************************
 *   Class gif2dp - converte GIF para Dynamic Publisher                    *
 *                                                                         *
 *   Copyright (C) 2018 by Marcelo Silveira                                *
 *   MSX Sketch Tools: http://marmsx.msxall.com                            *
 *   Contact: flamar98@hotmail.com                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

import java.io.*;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Color;
import javax.imageio.ImageIO;
import java.util.Arrays;


public class gif2dp {

  //
  // Ajuda
  //

  static void help() {
    System.out.println("-= MSX Sketch Tools - gif2dp2 =-");
    System.out.println("MarMSX 2018 - http://marmsx.msxall.com");
    System.out.println("Converte imagem GIF para arquivo do Dynamic Publisher");
    System.out.println("Uso: java gif2dp2 <imagem>");
    System.out.println("Exemplo:");
    System.out.println("java gif2dp2 pagina.gif");
  }


  //
  // Conversão para GIF
  //

  public static byte setBit(byte data, int b, boolean v) {
    int mask= 1 << b;

    if (v)
      return (byte) (data | mask);

    return (byte) (data & ~mask);
  }

  static byte switchNibbles(byte val) {
    int N1 = (val >> 4) & 0xF, N2 = val & 0xF;

    return (byte) ((N2 << 4) + N1);
  }

  static void formata(BufferedImage img, byte[] data) {
    byte dado;
    int p=0;

    for (int y=0; y<img.getHeight(); y++) {
      for (int x=0; x<img.getWidth(); x+=8) {        
        for (int b=0; b<8; b++)
          data[p] = setBit(data[p], b, (img.getRGB(x+(7-b), y) & 0xFF) < 128);
        data[p] = switchNibbles(data[p]);
        p++;
      }
    }
  }

  static void copyArray(byte dst[], byte src[], int p1, int p2, int size) {
    for (int i=0; i<size; i++)
      dst[p1+i] = src[p2+i];
  }

  // Compressor do DP
  static byte[] compactaLinha(byte[] linha) {
    byte linha2[] = new byte[linha.length*2];
    int p=0, p2=0, count;

    while (p < linha.length) {
      if (p == linha.length-1) {
        linha2[p2++] = 0;
        linha2[p2++] = linha[p];
        break;
      }

      if (linha[p] == linha[p+1]) {
        count=1;
        while (p+count < linha.length-1) {
          if (linha[p+count] != linha[p+count+1])
            break;
          count++;
         }
         linha2[p2++] = (byte) (count | 0x80);
         linha2[p2++] = linha[p];
         p += count+1;
      }
      else {
        count=1;
        while (p+count < linha.length-1) {
          if (linha[p+count] == linha[p+count+1])
            break;
          count++;
         }
         linha2[p2++] = (byte) (count-1);
         copyArray(linha2, linha, p2, p, count+1);
         p += count;
         p2 += count;
      }
    }

    return Arrays.copyOfRange(linha2, 0, p2);
  }

  static byte[] criaArquivo(byte [] data) {
    byte tmp[] = new byte[data.length], linha_cmp[];
    byte header[] = {0x44, 0x59, 0x4E, 0x41, 0x4D, 0x49, 0x43, 0x20, 0x50, 0x55, 0x42, 0x4C, 0x49, 0x53, 0x48, 0x45, 0x52, 0x20, 0x53, 0x43, 0x52, 0x45, 0x45, 0x4E};
    int p_data=0x180, p=0;

    // Insere header
    for (int i=0; i<header.length; i++)
      tmp[i] = header[i];
    tmp[0x81] = (byte) 0xFF;

    // Cria linha
    byte linha[] = new byte[64];

    // Compacta
    for (int i=0; i<704; i++) {
      copyArray(linha, data, 0, p, 64);
      linha_cmp = compactaLinha(linha);
      copyArray(tmp, linha_cmp, p_data, 0, linha_cmp.length);
      p += 64;
      p_data += linha_cmp.length;
    }

    return Arrays.copyOfRange(tmp, 0, p_data);
  }

  static void converte(String nomearq) {
    File arq = new File(nomearq);
    if (!arq.exists()) {
      System.out.println("Arquivo "+nomearq+" não existe.");
      return;
    }

    // Abre arquivo GIF
    BufferedImage img;
    try {
      img = ImageIO.read(new File(nomearq));
    }
    catch(Exception e) {
      System.out.println("Erro ao abrir o arquivo GIF.");
      return;
    }

    if (img==null) {
      System.out.println("Erro ao abrir o arquivo GIF.");
      return;
    }

    // Verifica se tamanho é compatível
    if (img.getWidth() != 512 || img.getHeight() != 704) {
      System.out.println("Arquivo com tamanho diferente.");
      return;
    }

    // Cria dados vazios
    byte[] data = new byte[64*704];

    // Formata e compacta dados
    byte file_data[];
    formata(img, data);
    file_data = criaArquivo(data);

    // Cria arquivo de saída
    String nomearq2 = nomearq.substring(0,nomearq.length()-4)+".PCT";
    arq = new File(nomearq2);
    try {
      OutputStream os = new FileOutputStream(arq);
      os.write(file_data);
      os.close();
    }
    catch(Exception e) {
      System.out.println("Erro ao salvar arquivos.");
      return;
    }
  }


  //
  // Método principal da classe
  //

  public static void main(String args[]) {

    if (args.length == 1)
      converte(args[0]);
    else
      help();
  }
}
