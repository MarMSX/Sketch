/***************************************************************************
 *   Class pm2gif - converte Page-Maker para GIF                           *
 *                                                                         *
 *   Copyright (C) 2018 by Marcelo Silveira                                *
 *   MSX Sketch Tools: http://marmsx.msxall.com                            *
 *   Contact: flamar98@hotmail.com                                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

import java.io.*;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Color;
import javax.imageio.ImageIO;


public class pm2gif {

  //
  // Ajuda
  //

  static void help() {
    System.out.println("-= MSX Sketch Tools - pm2gif =-");
    System.out.println("MarMSX 2018 - http://marmsx.msxall.com");
    System.out.println("Converte arquivo do Page-Maker para imagem GIF");
    System.out.println("Uso: java pm2gif <nome_base_arquivo>");
    System.out.println("Exemplo:");
    System.out.println("java pm2gif pagina");
  }


  //
  // Conversão para GIF
  //

  static boolean getPixelBit(byte pixel, int b) {
    return (boolean) (((pixel & (1 << b)) >> b) == 1);
  }

  static void renderizaSC2(BufferedImage img, byte[] data) {
    byte dado;
    int p=0;

    for (int y=0; y<img.getHeight(); y+=8) {
      for (int x=0; x<img.getWidth(); x+=8) {
        for (int yy=0; yy<8; yy++) {
          dado = data[p];
          for (int b=0; b<8; b++)
            img.setRGB(x+(7-b), y+yy, (getPixelBit(dado,b))?0:0xFFFFFF);
          p++;
        }
      }
    }
  }

  static void copyArray(byte[] dst, byte[] org, int p) {
    for (int i=0; i<org.length; i++)
      dst[i+p] = org[i];
  }

  static void converte(String nomearq) {
    // Nomes dos arquivos
    String pm_file[] = new String[4];
    for (int i=0; i<4; i++)
      pm_file[i] = nomearq+".PM"+Integer.toString(i+1);

    // Testes nos arquivos
    File arq;
    for (int i=0; i<4; i++) {
      arq = new File(pm_file[i]);

      if (!arq.exists()) {
        System.out.println("Arquivo "+pm_file[i]+" não existe.");
        return;
      }
      if (arq.length() != 12288)  {
        System.out.println("Tamanho de arquivo incompatível.");
        return;
      }
      if (nomearq.length() < 5) {
        System.out.println("Nome de arquivo curto.");
        return;
      }
    }

    // Abre arquivos e os coloca em um vetor
    byte[] data = new byte[49152];
    byte[] file_data = new byte[12288];
    for (int i=0; i<4; i++) {
      arq = new File(pm_file[i]);

      try {
        InputStream is = new FileInputStream(arq);
        is.read(file_data);
        is.close();
        copyArray(data, file_data, 12288*i);
      }
      catch(Exception e) {
        System.out.println("Erro ao abrir um arquivo.");
        return;
      }
    }

    // Cria a imagem vazia
    BufferedImage img;
    int width=512, height=768;
    int bg_color = 0xFFFFFF;
    img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    Graphics2D g2d = img.createGraphics();
    g2d.setColor(new Color(bg_color));
    g2d.fillRect(0, 0, width, height);

    // Renderiza
    renderizaSC2(img, data);

    // Salva arquivo GIF
    String nomearq2 = nomearq + ".GIF";
    try {
      File arq_gif = new File(nomearq2);
      ImageIO.write(img, "gif", arq_gif);
    }
    catch(Exception e) {
      System.out.println("Erro ao salvar o arquivo GIF.");
    }
  }


  //
  // Método principal da classe
  //

  public static void main(String args[]) {

    if (args.length == 1)
      converte(args[0]);
    else
      help();
  }
}
