-= MSX Sketch Tools =-

0- What's new?

* Version 1.2 - 02/05/2019
- PC shape bug fix while finding trash at the end of file.
- Added PC shape search for SDR files.


* Version 1.1 - 09/28/2018
- Shape bug fix on Page-Maker: file size must be multiple of 128 bytes.


1- Running MSX Sketch Tools

This program runs under any Operational System that has a Java Virtual Machine installed.

Included programs:
- sketch.jar

At the command prompt, use:
java -jar sketch.jar


2- Descriprion

The program "sketch.jar" is a graphic version of MSX Sketch Tools, which supports many images types conversion.

Supported images:

- PC
  - GIF - load / save

- MSX
  - GRP - load / save
  - Layout - load / save
  - Graphos III Shape - load / save
  - PC Shape - load
  - Dynamic Publisher Shape - load / save

It is possible to convert from an image type to another one. For that, first load image(s) from one type an then save image(s) as another type.
The program supports multiple images loading, except for the Graphos III shapes and the PC Shapes, once they are already multiple images.
When saving images, it is possible to save the current image or all images loaded.


3- Loading images

3.1 - PC

Click on "load" at "PC - GIF" panel. Select one or many GIF images to load.

3.2 - MSX

First, choose the MSX format on the combo box right below the "Load" button on "MSX" panel. Then click on "Load" button on "MSX" panel. Select one or many images to load, except for the Graphos III shapes or PC Shapes, where it is possible to select only one file.


4- Browsing images

The default screen showing mode is screen 2. Thus, if the image width is greater than 256 or height is greater than 192, the screen 6 mode is activated.
Images greater than 512x212 are not allowed.
Below the image panel, there are some informations and controls. The informations are:

FILE NAME                CURRENT IMAGE / TOTAL IMAGES
IMAGE SIZE        

The controls are
- Left arrow with line - goes to the first image
- Left arrow - back one image
- Right arrow with line - goes to the last image
- Right arrow - advance one image

Other controls (located below):
- Show 8x8 grid - show/hide 8x8 grid, only if screen mode is screen 2.
- Show image limits - show/hide image contour line.


5- Saving images

If there is more than one image to save, the program asks if you want to save the "current" image or "all" images. If "current", select the file name to save. If "all", select the destiny directory to save images. In that case, the program automatically creates the file name to save from the original image names by changing the file extension.

5.1 - PC

Click on "save" at "PC - GIF" panel.

5.2 - MSX

First, choose the MSX format on the combo box right below the "Save" button on "MSX" panel. Then click on "Save" button on "MSX" panel.
If save "all" is chosen for Graphos III, the program asks if you want:
- "Single file" - save all images in a single shape file.
- "Multiple files" - save all images in many shape files.

5.3 - IMPORTANT NOTICES

When saving all images, if the source file extension is the same as the destiny file extension, please choose a different directory to save from the original images.
This program checks if file exists before saving a file.


6- Informations

Author: Marcelo Silveira
Homepage: http://marmsx.msxall.com
E-mail: flamar98@hotmail.com
